# Kit mesh Sapa (pose idle)

Kanvas 1984 x 1648 px. Semua layer berukuran sama dan sudah sejajar, jadi cukup ditumpuk di posisi 0,0.

## Isi
- `sapa-idle-layer.psd`: semua layer dalam satu file (urutan bawah ke atas). Langsung bisa diimpor ke Live2D Cubism Editor.
- `layer/*.png`: layer yang sama sebagai PNG terpisah, untuk Spine, Rive, atau After Effects.
- `sapa-idle-layer.svg`: versi vektor dengan grup bernama per layer (Inkscape, Illustrator, Rive).
- `pivot.json` dan `panduan-pivot.png`: titik putar dalam piksel.
- `sapa-idle-komposit.png`: hasil akhir pose idle.

## Layer
| Layer | Default | Catatan |
|---|---|---|
| 00_bayangan | tampil | skala mengecil saat Sapa melompat |
| 01_lengan_kiri, 02_lengan_kanan | tampil | pangkal lengan tersembunyi di balik badan; putar di `bahu_kiri` / `bahu_kanan` |
| 03_badan, 04_wajah | tampil | napas: skala Y +1,4% dari `badan_dasar` |
| 05-06 pipi | tampil | |
| 07-08 mata putih | tampil | kedip: skala Y mata putih ke ~0 |
| 09-10 pupil | tampil | jadikan mata putih sebagai clipping mask supaya pupil tidak keluar saat melirik |
| 11-12 kelopak tutup | sembunyi | tampilkan di puncak kedipan |
| 13 mulut senyum | tampil | mulut diam |
| 14-17 mulut a, o, e, lebar | sembunyi | bentuk mulut untuk lip-sync TTS |

## Pemetaan mulut untuk lip-sync
- Diam / jeda: `mulut_senyum`
- Vokal a: `mulut_a`
- Vokal o, u: `mulut_o`
- Vokal e, i: `mulut_e`
- Senang / tertawa: `mulut_lebar`

## Gerakan idle yang dipakai di animasi contoh (loop 3 detik)
- Badan naik-turun 1,6 unit, napas 1,4%, miring 0,8 derajat.
- Lengan berayun ±3 derajat berlawanan arah.
- Pupil melirik ±1,5 unit ke samping.
- Satu kedipan di 72% durasi.

Nilai "unit" mengikuti koordinat SVG; kalikan 8 untuk piksel di kanvas ini.
