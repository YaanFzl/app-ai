/**
 * Naskah Sapa: apa yang diucapkan (TTS), apa yang tampil (subtitle), dan pose avatar.
 *
 * - `NASKAH` bertipe mapped type atas semua Tag → lupa satu keadaan = error kompilasi.
 * - Kalimat ditulis manusia dan ditinjau; tidak ada LLM yang mengarang ucapan ke pasien.
 * - Nama, NIK, nomor kartu, dan poli TIDAK PERNAH diucapkan (dijamin tipe `ucap`),
 *   karena kios memakai speaker di ruang publik. Data itu hanya tampil di layar.
 */
import type { AlasanPetugas } from "./domain.js";
import type { KeadaanDengan, Keadaan, Tag } from "./mesin.js";
import { ucap, type Giliran } from "./ucapan.js";

type Naskah = { readonly [T in Tag]: (s: KeadaanDengan<T>) => Giliran };

const pelan = 0.85 as const;
const sedang = 0.9 as const;

const ALASAN_TERUCAP: { readonly [A in AlasanPetugas]: Giliran["ucapan"] } = {
  izin_ditolak: ucap`Baik, tidak apa-apa. Petugas akan membantu langsung, ya.`,
  diminta_pasien: ucap`Baik. Petugas segera datang membantu.`,
  kartu_tak_terbaca: ucap`Kartunya belum terbaca. Tidak apa-apa, petugas segera datang membantu.`,
  peserta_tidak_aktif: ucap`Ada yang perlu dicek petugas. Mohon tunggu sebentar, ya.`,
  frista_tidak_cocok: ucap`Tidak apa-apa. Petugas segera datang untuk membantu verifikasi.`,
  frista_wajah_tak_terdeteksi: ucap`Kameranya belum bisa membaca wajah. Tidak apa-apa, petugas segera datang.`,
  jawaban_tidak_jelas: ucap`Maaf, saya belum menangkap jawabannya. Petugas segera datang membantu.`,
  diam_terlalu_lama: ucap`Petugas segera datang membantu, ya.`,
  kebutuhan_lain: ucap`Untuk keperluan itu, petugas akan membantu langsung.`,
  dokumen_tak_terbaca: ucap`Suratnya belum terbaca. Tidak apa-apa, petugas segera datang.`,
  data_dikoreksi_pasien: ucap`Terima kasih sudah memeriksa. Petugas akan membetulkan datanya bersama.`,
  layanan_ai_terputus: ucap`Maaf, sistem saya sedang lambat. Petugas segera datang membantu.`,
  kemungkinan_darurat: ucap`Saya panggilkan petugas sekarang juga. Silakan duduk dulu, ya.`,
};

export const NASKAH: Naskah = {
  SAPA_IZIN: (s) =>
    s.k.ulang === 0
      ? {
          ucapan: ucap`Selamat datang, ${"Bapak/Ibu"}. Saya Sapa, pemandu pendaftaran. Data Bapak atau Ibu akan dipakai untuk pendaftaran hari ini. Boleh saya lanjutkan?`,
          subtitle: "Boleh saya bantu daftar? Jawab: ya / tidak",
          ekspresi: "menyapa",
          tempo: pelan,
        }
      : {
          ucapan: ucap`Maaf, saya kurang dengar. Boleh saya lanjutkan? Cukup jawab ya, atau tidak.`,
          subtitle: "Cukup jawab: ya / tidak",
          ekspresi: "mendengar",
          tempo: pelan,
        },

  MINTA_KARTU: (s) =>
    s.percobaan === 1 && s.k.ulang === 0
      ? {
          ucapan: ucap`Terima kasih. Silakan letakkan kartu BPJS atau KTP di kotak yang menyala.`,
          subtitle: "Letakkan kartu BPJS / KTP di kotak yang menyala",
          ekspresi: "memandu",
          tempo: sedang,
        }
      : {
          ucapan: ucap`Kartunya belum terbaca. Coba letakkan lagi, rata dengan kaca, ya.`,
          subtitle: "Letakkan lagi kartunya, rata dengan kaca",
          ekspresi: "memandu",
          tempo: pelan,
        },

  VERIFIKASI_WAJAH: (s) => {
    const sp = s.k.sapaan;
    switch (s.pandu) {
      case "awal":
        return { ucapan: ucap`Terima kasih, ${sp}. Sekarang lihat ke kamera di atas layar, ya.`, subtitle: "Lihat ke kamera di atas layar", ekspresi: "memandu", tempo: sedang };
      case "maju":
        return { ucapan: ucap`Sedikit maju, ${sp}. Ya, begitu. Tahan sebentar.`, subtitle: "Sedikit maju… tahan sebentar", ekspresi: "memandu", tempo: pelan };
      case "terang":
        return { ucapan: ucap`Saya terangkan lampunya. Lihat ke kamera sekali lagi, ya.`, subtitle: "Lampu diterangkan. Lihat ke kamera lagi", ekspresi: "memandu", tempo: pelan };
      case "lepas_penutup":
        return { ucapan: ucap`Boleh masker atau topinya dilepas sebentar, ${sp}?`, subtitle: "Boleh lepas masker / topi sebentar?", ekspresi: "memandu", tempo: pelan };
      case "ulang":
        return { ucapan: ucap`Kita coba sekali lagi. Lihat lurus ke kamera, ya.`, subtitle: "Coba lagi: lihat lurus ke kamera", ekspresi: "memandu", tempo: pelan };
    }
  },

  TANYA_KUNJUNGAN: (s) =>
    s.k.ulang === 0
      ? {
          ucapan: ucap`Wajah sudah cocok, terima kasih. Hari ini ${s.k.sapaan} mau kontrol, atau membawa rujukan baru?`,
          subtitle: "Kontrol, atau bawa rujukan baru?",
          ekspresi: "mendengar",
          tempo: sedang,
        }
      : {
          ucapan: ucap`Maaf, boleh diulang? Kontrol, atau rujukan baru?`,
          subtitle: "Kontrol, atau rujukan baru?",
          ekspresi: "mendengar",
          tempo: pelan,
        },

  SCAN_DOKUMEN: (s) => {
    const rujukan = s.k.kunjungan === "rujukan_baru";
    if (s.percobaan > 1 || s.k.ulang > 0) {
      return { ucapan: ucap`Suratnya belum terbaca. Coba letakkan lagi, tulisannya menghadap ke bawah, ya.`, subtitle: "Letakkan lagi suratnya, tulisan menghadap kaca", ekspresi: "memandu", tempo: pelan };
    }
    return rujukan
      ? { ucapan: ucap`Silakan letakkan surat rujukan dari puskesmas atau klinik di kotak yang menyala.`, subtitle: "Letakkan surat rujukan di kotak yang menyala", ekspresi: "memandu", tempo: sedang }
      : { ucapan: ucap`Silakan letakkan surat kontrol di kotak yang menyala.`, subtitle: "Letakkan surat kontrol di kotak yang menyala", ekspresi: "memandu", tempo: sedang };
  },

  KONFIRMASI_DATA: (s) =>
    s.k.ulang === 0
      ? {
          ucapan: ucap`Data kunjungan ${s.k.sapaan} ada di layar. Sudah betul?`,
          subtitle: "Data di layar sudah betul? Jawab: ya / tidak",
          ekspresi: "mendengar",
          tempo: sedang,
        }
      : {
          ucapan: ucap`Maaf, saya kurang dengar. Data di layar sudah betul? Cukup jawab ya, atau tidak.`,
          subtitle: "Data di layar sudah betul? Ya / tidak",
          ekspresi: "mendengar",
          tempo: pelan,
        },

  MENUNGGU_PETUGAS_CEK: () => ({
    ucapan: ucap`Terima kasih. Petugas sedang memeriksa sebentar, ya.`,
    subtitle: "Petugas sedang memeriksa sebentar…",
    ekspresi: "senang",
    tempo: sedang,
  }),

  MEMANGGIL_PETUGAS: (s) => ({
    ucapan: ALASAN_TERUCAP[s.alasan],
    subtitle: s.alasan === "kemungkinan_darurat" ? "Petugas dipanggil SEKARANG. Silakan duduk dulu" : "Petugas segera datang membantu",
    ekspresi: "petugas",
    tempo: pelan,
  }),

  SELESAI: (s) =>
    s.hasil === "antrean_dicetak"
      ? { ucapan: ucap`Ini nomor antrean ${s.k.sapaan}. Semua keterangan ada di struk. Semoga lekas sehat.`, subtitle: "Ambil struk antrean di bawah. Semoga lekas sehat!", ekspresi: "senang", tempo: sedang }
      : { ucapan: ucap`Petugas sudah di sini. Semoga lekas sehat, ${s.k.sapaan}.`, subtitle: "Petugas sudah di sini. Semoga lekas sehat!", ekspresi: "senang", tempo: sedang },
};

export function giliranUntuk(s: Keadaan): Giliran {
  // Satu-satunya cast: TS tidak bisa mengaitkan s.tag dengan parameter fungsi di mapped type.
  return (NASKAH[s.tag] as (x: Keadaan) => Giliran)(s);
}
