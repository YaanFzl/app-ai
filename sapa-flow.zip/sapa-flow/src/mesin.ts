/**
 * State machine alur Sapa. Fungsi murni: (keadaan, peristiwa) → (keadaan berikut, efek).
 *
 * Jaminan yang dipegang oleh TIPE (bukan dokumen):
 *  1. Tidak ada keadaan "DITOLAK". Satu-satunya akhir adalah SELESAI dengan hasil
 *     `antrean_dicetak` atau `dilayani_petugas`  → kios tidak pernah menolak pasien.
 *  2. Setiap keadaan wajib punya naskah (lihat `NASKAH` di naskah.ts, mapped type).
 *  3. `switch` atas keadaan & peristiwa dicek tuntas (`tuntas(x: never)`).
 *  4. Kios tidak menulis ke SIMRS/BPJS: efek paling jauh adalah `kirim_draf_ke_petugas`.
 */
import type { AlasanPetugas, BenderaData, DokumenOcr, HasilFrista, IdentitasKartu, Sapaan } from "./domain.js";
import type { Pemahaman } from "./pemahaman.js";
import type { Giliran } from "./ucapan.js";
import type { Topik } from "./pertanyaan.js";
import { cocokkan } from "./cocokkan.js";
import { giliranUntuk } from "./naskah.js";

// ---------------------------------------------------------------- konteks sesi
export interface Konteks {
  readonly hariIni: string; // YYYY-MM-DD, disuntik saat sesi dibuat (fungsi tetap murni)
  readonly sapaan: Sapaan;
  readonly izin: boolean;
  readonly identitas: IdentitasKartu | null;
  readonly kunjungan: "kontrol" | "rujukan_baru" | null;
  readonly dokumen: DokumenOcr | null;
  readonly bendera: readonly BenderaData[];
  /** Berapa kali pertanyaan saat ini harus diulang (tidak jelas / diam). */
  readonly ulang: number;
}

export const BATAS = {
  tanyaUlang: 2, // jawaban tidak jelas/diam ke-2 → petugas
  kartu: 2,
  wajahTakTerdeteksi: 3,
  wajahTidakCocok: 2,
  dokumen: 2,
} as const;

export type Pandu = "awal" | "maju" | "terang" | "lepas_penutup" | "ulang";

// ---------------------------------------------------------------- keadaan
export type Keadaan =
  | { readonly tag: "SAPA_IZIN"; readonly k: Konteks }
  | { readonly tag: "MINTA_KARTU"; readonly k: Konteks; readonly percobaan: number }
  | { readonly tag: "VERIFIKASI_WAJAH"; readonly k: Konteks; readonly percobaan: number; readonly tidakCocok: number; readonly pandu: Pandu }
  | { readonly tag: "TANYA_KUNJUNGAN"; readonly k: Konteks }
  | { readonly tag: "SCAN_DOKUMEN"; readonly k: Konteks; readonly percobaan: number }
  | { readonly tag: "KONFIRMASI_DATA"; readonly k: Konteks }
  | { readonly tag: "MENUNGGU_PETUGAS_CEK"; readonly k: Konteks }
  | { readonly tag: "MEMANGGIL_PETUGAS"; readonly k: Konteks; readonly alasan: AlasanPetugas }
  | { readonly tag: "SELESAI"; readonly k: Konteks; readonly hasil: HasilAkhir };

/** Perhatikan: tidak ada "ditolak". Diuji juga di tes tipe. */
export type HasilAkhir = "antrean_dicetak" | "dilayani_petugas";
export type Tag = Keadaan["tag"];
export type KeadaanDengan<T extends Tag> = Extract<Keadaan, { tag: T }>;

/** Keadaan yang sedang menunggu jawaban lisan, dan topik pertanyaannya. */
export const TOPIK_KEADAAN = {
  SAPA_IZIN: "izin",
  TANYA_KUNJUNGAN: "kunjungan",
  KONFIRMASI_DATA: "konfirmasi",
} as const satisfies Partial<Record<Tag, Topik>>;

// ---------------------------------------------------------------- peristiwa
type Jawaban = { [T in Topik]: { readonly tipe: "JAWABAN"; readonly topik: T; readonly hasil: Pemahaman<T> } }[Topik];

export type Peristiwa =
  | Jawaban
  | { readonly tipe: "KARTU_TERBACA"; readonly identitas: IdentitasKartu }
  | { readonly tipe: "KARTU_GAGAL" }
  | { readonly tipe: "FRISTA"; readonly hasil: HasilFrista }
  | { readonly tipe: "DOKUMEN_TERBACA"; readonly dokumen: DokumenOcr }
  | { readonly tipe: "DOKUMEN_GAGAL" }
  | { readonly tipe: "TOMBOL_ULANGI" }
  | { readonly tipe: "TOMBOL_PETUGAS" }
  | { readonly tipe: "DIAM" }
  | { readonly tipe: "PETUGAS_TIBA" }
  | { readonly tipe: "PETUGAS_SETUJU" }
  | { readonly tipe: "PETUGAS_AMBIL_ALIH" };

// ---------------------------------------------------------------- efek
/** Data yang tampil di layar (boleh pribadi) — tidak pernah lewat speaker. */
export interface KartuLayar {
  readonly judul: string;
  readonly baris: readonly { readonly label: string; readonly nilai: string; readonly ragu: boolean }[];
}

export interface DrafPendaftaran {
  readonly identitas: IdentitasKartu | null;
  readonly kunjungan: Konteks["kunjungan"];
  readonly dokumen: DokumenOcr | null;
  readonly bendera: readonly BenderaData[];
  readonly sumberKolom: Readonly<Record<string, "kartu" | "ocr" | "jawaban_lisan">>;
}

export type CatatanAudit =
  | { readonly jenis: "izin"; readonly diberikan: boolean }
  | { readonly jenis: "frista"; readonly hasil: HasilFrista["hasil"]; readonly percobaan: number }
  | { readonly jenis: "pemahaman"; readonly topik: Topik; readonly hasil: Pemahaman<Topik>["jenis"]; readonly sumber?: string }
  | { readonly jenis: "bendera"; readonly bendera: readonly BenderaData[] }
  | { readonly jenis: "eskalasi"; readonly alasan: AlasanPetugas; readonly dari: Tag }
  | { readonly jenis: "keputusan_petugas"; readonly keputusan: "setuju" | "ambil_alih" | "tiba" }
  | { readonly jenis: "diabaikan"; readonly peristiwa: Peristiwa["tipe"]; readonly di: Tag };

export type Efek =
  | { readonly efek: "bicara"; readonly giliran: Giliran }
  | { readonly efek: "tampilkan_kartu"; readonly isi: KartuLayar }
  | { readonly efek: "lampu"; readonly target: "pemindai" | "wajah"; readonly nyala: boolean }
  | { readonly efek: "kamera"; readonly aksi: "bingkai_otomatis" | "naikkan_eksposur" }
  | { readonly efek: "panggil_petugas"; readonly alasan: AlasanPetugas; readonly prioritas: "biasa" | "segera" }
  | { readonly efek: "kirim_draf_ke_petugas"; readonly draf: DrafPendaftaran }
  | { readonly efek: "cetak_antrean" }
  | { readonly efek: "audit"; readonly catatan: CatatanAudit };

export interface Langkah {
  readonly berikut: Keadaan;
  readonly efek: readonly Efek[];
}

// ---------------------------------------------------------------- utilitas
export function tuntas(x: never): never {
  throw new Error(`Kasus tidak tertangani: ${JSON.stringify(x)}`);
}

export function mulai(hariIni: string): Langkah {
  const k: Konteks = { hariIni, sapaan: "Bapak/Ibu", izin: false, identitas: null, kunjungan: null, dokumen: null, bendera: [], ulang: 0 };
  return masuk({ tag: "SAPA_IZIN", k });
}

/** Efek saat MEMASUKI sebuah keadaan: naskah + perangkat. */
export function masuk(s: Keadaan, sebelum: readonly Efek[] = []): Langkah {
  const efek: Efek[] = [...sebelum];
  switch (s.tag) {
    case "SAPA_IZIN":
    case "TANYA_KUNJUNGAN":
    case "MENUNGGU_PETUGAS_CEK":
      break;
    case "MINTA_KARTU":
    case "SCAN_DOKUMEN":
      efek.push({ efek: "lampu", target: "pemindai", nyala: true });
      break;
    case "VERIFIKASI_WAJAH":
      efek.push({ efek: "lampu", target: "pemindai", nyala: false });
      efek.push({ efek: "lampu", target: "wajah", nyala: true });
      efek.push({ efek: "kamera", aksi: s.pandu === "terang" ? "naikkan_eksposur" : "bingkai_otomatis" });
      break;
    case "KONFIRMASI_DATA":
      efek.push({ efek: "lampu", target: "pemindai", nyala: false });
      efek.push({ efek: "tampilkan_kartu", isi: kartuKonfirmasi(s.k) });
      break;
    case "MEMANGGIL_PETUGAS":
      efek.push({ efek: "panggil_petugas", alasan: s.alasan, prioritas: s.alasan === "kemungkinan_darurat" ? "segera" : "biasa" });
      efek.push({ efek: "kirim_draf_ke_petugas", draf: draf(s.k) });
      break;
    case "SELESAI":
      if (s.hasil === "antrean_dicetak") efek.push({ efek: "cetak_antrean" });
      break;
    default:
      return tuntas(s);
  }
  efek.push({ efek: "bicara", giliran: giliranUntuk(s) });
  return { berikut: s, efek };
}

function keKonteks(k: Konteks, ubah: Partial<Konteks>): Konteks {
  return { ...k, ...ubah };
}

function panggilPetugas(dari: Keadaan, alasan: AlasanPetugas, sebelum: readonly Efek[] = []): Langkah {
  return masuk({ tag: "MEMANGGIL_PETUGAS", k: keKonteks(dari.k, { ulang: 0 }), alasan }, [
    ...sebelum,
    { efek: "audit", catatan: { jenis: "eskalasi", alasan, dari: dari.tag } },
  ]);
}

/** Jawaban tidak jelas / diam: ulangi pertanyaan, atau panggil petugas setelah batas. */
function ulangiAtauPetugas(s: Keadaan, alasan: AlasanPetugas, sebelum: readonly Efek[] = []): Langkah {
  const ulang = s.k.ulang + 1;
  if (ulang >= BATAS.tanyaUlang) return panggilPetugas(s, alasan, sebelum);
  return masuk({ ...s, k: keKonteks(s.k, { ulang }) } as Keadaan, sebelum);
}

function diabaikan(s: Keadaan, p: Peristiwa): Langkah {
  return { berikut: s, efek: [{ efek: "audit", catatan: { jenis: "diabaikan", peristiwa: p.tipe, di: s.tag } }] };
}

function draf(k: Konteks): DrafPendaftaran {
  return {
    identitas: k.identitas,
    kunjungan: k.kunjungan,
    dokumen: k.dokumen,
    bendera: k.bendera,
    sumberKolom: {
      ...(k.identitas ? { nama: "kartu", nik: "kartu", tanggalLahir: "kartu" } : {}),
      ...(k.kunjungan ? { kunjungan: "jawaban_lisan" } : {}),
      ...(k.dokumen ? { poliTujuan: "ocr", berlakuSampai: "ocr" } : {}),
    },
  };
}

function kartuKonfirmasi(k: Konteks): KartuLayar {
  const ragu = (kolom: string) => k.bendera.some((b) => b.kolom === kolom || (b.kolom === "ocr_ragu" && b.kolomRagu === kolom));
  const poli = k.dokumen?.poliTujuan.nilai ?? "-";
  return {
    judul: "Data kunjungan hari ini",
    baris: [
      { label: "Nama", nilai: k.identitas?.nama ?? "-", ragu: ragu("nama") },
      { label: "Tanggal lahir", nilai: k.identitas?.tanggalLahir ?? "-", ragu: ragu("tanggalLahir") },
      { label: "Kunjungan", nilai: k.kunjungan === "kontrol" ? "Kontrol" : "Rujukan baru", ragu: false },
      { label: "Poli tujuan", nilai: poli.replace(/_/g, " "), ragu: ragu("poliTujuan") },
      { label: "Rujukan berlaku s.d.", nilai: k.dokumen?.berlakuSampai.nilai ?? "-", ragu: ragu("rujukan_kedaluwarsa") || ragu("berlakuSampai") },
    ],
  };
}

const auditPemahaman = (topik: Topik, h: Pemahaman<Topik>): Efek => ({
  efek: "audit",
  catatan: { jenis: "pemahaman", topik, hasil: h.jenis, ...(h.jenis === "pasti" ? { sumber: h.sumber } : {}) },
});

// ---------------------------------------------------------------- transisi
export function langkah(s: Keadaan, p: Peristiwa): Langkah {
  // Akhir bersifat menyerap.
  if (s.tag === "SELESAI") return diabaikan(s, p);

  // Peristiwa global
  switch (p.tipe) {
    case "TOMBOL_ULANGI":
      return { berikut: s, efek: [{ efek: "bicara", giliran: giliranUntuk(s) }] };
    case "TOMBOL_PETUGAS":
      if (s.tag === "MEMANGGIL_PETUGAS" || s.tag === "MENUNGGU_PETUGAS_CEK") return diabaikan(s, p);
      return panggilPetugas(s, "diminta_pasien");
    case "DIAM":
      if (s.tag === "MEMANGGIL_PETUGAS" || s.tag === "MENUNGGU_PETUGAS_CEK") return diabaikan(s, p);
      return ulangiAtauPetugas(s, "diam_terlalu_lama");
    case "JAWABAN":
      // Darurat menang atas segalanya, termasuk saat sudah menunggu petugas (naikkan prioritas).
      if (p.hasil.jenis === "darurat") {
        if (s.tag === "MEMANGGIL_PETUGAS" && s.alasan === "kemungkinan_darurat") return diabaikan(s, p);
        return panggilPetugas(s, "kemungkinan_darurat", [auditPemahaman(p.topik, p.hasil)]);
      }
      if (p.hasil.jenis === "minta_petugas" && s.tag !== "MEMANGGIL_PETUGAS" && s.tag !== "MENUNGGU_PETUGAS_CEK") {
        return panggilPetugas(s, "diminta_pasien", [auditPemahaman(p.topik, p.hasil)]);
      }
      break;
    case "KARTU_TERBACA":
    case "KARTU_GAGAL":
    case "FRISTA":
    case "DOKUMEN_TERBACA":
    case "DOKUMEN_GAGAL":
    case "PETUGAS_TIBA":
    case "PETUGAS_SETUJU":
    case "PETUGAS_AMBIL_ALIH":
      break;
    default:
      return tuntas(p);
  }

  switch (s.tag) {
    case "SAPA_IZIN": {
      if (p.tipe !== "JAWABAN" || p.topik !== "izin") return diabaikan(s, p);
      const a = auditPemahaman("izin", p.hasil);
      switch (p.hasil.jenis) {
        case "pasti":
          if (p.hasil.opsi === "ya") {
            return masuk({ tag: "MINTA_KARTU", k: keKonteks(s.k, { izin: true, ulang: 0 }), percobaan: 1 }, [
              a,
              { efek: "audit", catatan: { jenis: "izin", diberikan: true } },
            ]);
          }
          return panggilPetugas(s, "izin_ditolak", [a, { efek: "audit", catatan: { jenis: "izin", diberikan: false } }]);
        case "tanya_ulang":
          return ulangiAtauPetugas(s, p.hasil.sebab === "layanan_terputus" ? "layanan_ai_terputus" : "jawaban_tidak_jelas", [a]);
        case "minta_petugas":
          return panggilPetugas(s, "diminta_pasien", [a]);
        case "darurat":
          return panggilPetugas(s, "kemungkinan_darurat", [a]);
        default:
          return tuntas(p.hasil);
      }
    }

    case "MINTA_KARTU": {
      if (p.tipe === "KARTU_TERBACA") {
        if (p.identitas.statusPeserta === "tidak_aktif") return panggilPetugas(s, "peserta_tidak_aktif");
        const sapaan = p.identitas.jenisKelamin === "L" ? "Bapak" : "Ibu";
        return masuk({
          tag: "VERIFIKASI_WAJAH",
          k: keKonteks(s.k, { identitas: p.identitas, sapaan, ulang: 0 }),
          percobaan: 1,
          tidakCocok: 0,
          pandu: "awal",
        });
      }
      if (p.tipe === "KARTU_GAGAL") {
        if (s.percobaan >= BATAS.kartu) return panggilPetugas(s, "kartu_tak_terbaca");
        return masuk({ ...s, percobaan: s.percobaan + 1 });
      }
      return diabaikan(s, p);
    }

    case "VERIFIKASI_WAJAH": {
      if (p.tipe !== "FRISTA") return diabaikan(s, p);
      const a: Efek = { efek: "audit", catatan: { jenis: "frista", hasil: p.hasil.hasil, percobaan: s.percobaan } };
      switch (p.hasil.hasil) {
        case "cocok":
          return masuk({ tag: "TANYA_KUNJUNGAN", k: keKonteks(s.k, { ulang: 0 }) }, [a, { efek: "lampu", target: "wajah", nyala: false }]);
        case "wajah_tidak_terdeteksi": {
          if (s.percobaan >= BATAS.wajahTakTerdeteksi) return panggilPetugas(s, "frista_wajah_tak_terdeteksi", [a]);
          const pandu: Pandu =
            p.hasil.sebab === "terlalu_jauh" ? "maju" : p.hasil.sebab === "gelap" ? "terang" : p.hasil.sebab === "tertutup" ? "lepas_penutup" : "ulang";
          return masuk({ ...s, percobaan: s.percobaan + 1, pandu }, [a]);
        }
        case "tidak_cocok": {
          const tidakCocok = s.tidakCocok + 1;
          if (tidakCocok >= BATAS.wajahTidakCocok) return panggilPetugas(s, "frista_tidak_cocok", [a]);
          return masuk({ ...s, percobaan: s.percobaan + 1, tidakCocok, pandu: "ulang" }, [a]);
        }
        default:
          return tuntas(p.hasil);
      }
    }

    case "TANYA_KUNJUNGAN": {
      if (p.tipe !== "JAWABAN" || p.topik !== "kunjungan") return diabaikan(s, p);
      const a = auditPemahaman("kunjungan", p.hasil);
      switch (p.hasil.jenis) {
        case "pasti":
          if (p.hasil.opsi === "lainnya") return panggilPetugas(s, "kebutuhan_lain", [a]);
          return masuk({ tag: "SCAN_DOKUMEN", k: keKonteks(s.k, { kunjungan: p.hasil.opsi, ulang: 0 }), percobaan: 1 }, [a]);
        case "tanya_ulang":
          return ulangiAtauPetugas(s, p.hasil.sebab === "layanan_terputus" ? "layanan_ai_terputus" : "jawaban_tidak_jelas", [a]);
        case "minta_petugas":
          return panggilPetugas(s, "diminta_pasien", [a]);
        case "darurat":
          return panggilPetugas(s, "kemungkinan_darurat", [a]);
        default:
          return tuntas(p.hasil);
      }
    }

    case "SCAN_DOKUMEN": {
      if (p.tipe === "DOKUMEN_TERBACA") {
        if (!s.k.identitas) return panggilPetugas(s, "kartu_tak_terbaca"); // tidak mungkin lewat alur normal; aman
        const bendera = cocokkan(s.k.identitas, p.dokumen, s.k.hariIni);
        const jenisSalah = (s.k.kunjungan === "rujukan_baru") !== (p.dokumen.jenis === "rujukan_fktp");
        const semua = jenisSalah ? [...bendera, { kolom: "ocr_ragu", kolomRagu: "jenis_dokumen" } as const] : bendera;
        const efekBendera: Efek[] = semua.length ? [{ efek: "audit", catatan: { jenis: "bendera", bendera: semua } }] : [];
        return masuk({ tag: "KONFIRMASI_DATA", k: keKonteks(s.k, { dokumen: p.dokumen, bendera: semua, ulang: 0 }) }, efekBendera);
      }
      if (p.tipe === "DOKUMEN_GAGAL") {
        if (s.percobaan >= BATAS.dokumen) return panggilPetugas(s, "dokumen_tak_terbaca");
        return masuk({ ...s, percobaan: s.percobaan + 1 });
      }
      return diabaikan(s, p);
    }

    case "KONFIRMASI_DATA": {
      if (p.tipe !== "JAWABAN" || p.topik !== "konfirmasi") return diabaikan(s, p);
      const a = auditPemahaman("konfirmasi", p.hasil);
      switch (p.hasil.jenis) {
        case "pasti":
          if (p.hasil.opsi === "tidak") return panggilPetugas(s, "data_dikoreksi_pasien", [a]);
          return masuk({ tag: "MENUNGGU_PETUGAS_CEK", k: keKonteks(s.k, { ulang: 0 }) }, [
            a,
            { efek: "kirim_draf_ke_petugas", draf: draf(s.k) },
          ]);
        case "tanya_ulang":
          return ulangiAtauPetugas(s, p.hasil.sebab === "layanan_terputus" ? "layanan_ai_terputus" : "jawaban_tidak_jelas", [a]);
        case "minta_petugas":
          return panggilPetugas(s, "diminta_pasien", [a]);
        case "darurat":
          return panggilPetugas(s, "kemungkinan_darurat", [a]);
        default:
          return tuntas(p.hasil);
      }
    }

    case "MENUNGGU_PETUGAS_CEK": {
      if (p.tipe === "PETUGAS_SETUJU") {
        return masuk({ tag: "SELESAI", k: s.k, hasil: "antrean_dicetak" }, [{ efek: "audit", catatan: { jenis: "keputusan_petugas", keputusan: "setuju" } }]);
      }
      if (p.tipe === "PETUGAS_AMBIL_ALIH") {
        return masuk({ tag: "SELESAI", k: s.k, hasil: "dilayani_petugas" }, [{ efek: "audit", catatan: { jenis: "keputusan_petugas", keputusan: "ambil_alih" } }]);
      }
      return diabaikan(s, p);
    }

    case "MEMANGGIL_PETUGAS": {
      if (p.tipe === "PETUGAS_TIBA") {
        return masuk({ tag: "SELESAI", k: s.k, hasil: "dilayani_petugas" }, [{ efek: "audit", catatan: { jenis: "keputusan_petugas", keputusan: "tiba" } }]);
      }
      return diabaikan(s, p);
    }

    default:
      return tuntas(s);
  }
}
