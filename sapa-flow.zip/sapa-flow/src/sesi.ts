/**
 * Runner sesi: menjembatani peristiwa mentah perangkat (termasuk transkrip ucapan)
 * ke mesin murni. Hanya di sini ada I/O ke Jev / Claude.
 */
import { langkah, type Keadaan, type Langkah, type Peristiwa, TOPIK_KEADAAN, type Tag } from "./mesin.js";
import { giliranUntuk } from "./naskah.js";
import { AMBANG, pahami, type Ambang, type Jejak, type Penilai } from "./pemahaman.js";
import type { Topik } from "./pertanyaan.js";
import { samarkan } from "./samarkan.js";

export type PeristiwaMentah = Exclude<Peristiwa, { tipe: "JAWABAN" }> | { readonly tipe: "UCAPAN_PASIEN"; readonly transkrip: string };

export interface LangkahSesi extends Langkah {
  readonly jejak?: Jejak;
}

export function topikUntuk(tag: Tag): Topik | null {
  return (TOPIK_KEADAAN as Partial<Record<Tag, Topik>>)[tag] ?? null;
}

export async function proses(s: Keadaan, pm: PeristiwaMentah, penilai: Penilai, ambang: Ambang = AMBANG): Promise<LangkahSesi> {
  if (pm.tipe !== "UCAPAN_PASIEN") return langkah(s, pm);
  const topik = topikUntuk(s.tag);
  if (!topik) {
    return { berikut: s, efek: [{ efek: "audit", catatan: { jenis: "diabaikan", peristiwa: "JAWABAN", di: s.tag } }] };
  }
  const m = { pertanyaanKios: giliranUntuk(s).subtitle, ujaran: samarkan(pm.transkrip) };
  switch (topik) {
    case "izin": {
      const r = await pahami("izin", m, penilai, ambang);
      return { ...langkah(s, { tipe: "JAWABAN", topik, hasil: r.hasil }), jejak: r.jejak };
    }
    case "kunjungan": {
      const r = await pahami("kunjungan", m, penilai, ambang);
      return { ...langkah(s, { tipe: "JAWABAN", topik, hasil: r.hasil }), jejak: r.jejak };
    }
    case "konfirmasi": {
      const r = await pahami("konfirmasi", m, penilai, ambang);
      return { ...langkah(s, { tipe: "JAWABAN", topik, hasil: r.hasil }), jejak: r.jejak };
    }
  }
}
