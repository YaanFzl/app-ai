import { test } from "node:test";
import assert from "node:assert/strict";
import fc from "fast-check";
import { BATAS, langkah, mulai, type Efek, type Keadaan, type Peristiwa } from "../src/mesin.js";
import { proses, type PeristiwaMentah } from "../src/sesi.js";
import type { Penilai } from "../src/pemahaman.js";
import { HARI_INI, KARTU_AHMAD, KARTU_SITI, penilaiPalsu, rujukanUntuk, type JawabJev } from "./palsu.js";

// ---------------------------------------------------------------- penilai palsu untuk skenario
const TABEL_JEV: Record<string, JawabJev> = {
  "iya boleh": { choice: "ya", confidence: 0.92 },
  nggak: { choice: "tidak", confidence: 0.9 },
  "kontrol rutin, Nak": { choice: "kontrol", confidence: 0.88 },
  "bawa surat dari puskesmas": { choice: "rujukan_baru", confidence: 0.91 },
  "kulo ajeng kontrol": { choice: "kontrol", confidence: 0.5 }, // nanggung → Claude
  betul: { choice: "ya", confidence: 0.95 },
  "ehm gimana ya": { choice: "tidak_jelas", confidence: 0.8 },
  "panggilkan suster saja": { choice: "tidak_jelas", confidence: 0.4, noul: 0.95 },
};
const penilaiStandar = () =>
  penilaiPalsu(
    (u) => TABEL_JEV[u] ?? { choice: "tidak_jelas", confidence: 0.9 },
    (u) => ({ opsi: u === "kulo ajeng kontrol" ? "kontrol" : "tidak_jelas", minta_petugas: false }),
  );

async function jalankan(urutan: PeristiwaMentah[], penilai: Penilai = penilaiStandar()) {
  let { berikut: s, efek } = mulai(HARI_INI);
  cekGiliran(s, efek);
  const semuaEfek: Efek[] = [...efek];
  const jalur: string[] = [s.tag];
  for (const pm of urutan) {
    const r = await proses(s, pm, penilai);
    s = r.berikut;
    cekGiliran(s, r.efek);
    semuaEfek.push(...r.efek);
    jalur.push(s.tag);
  }
  return { s, efek: semuaEfek, jalur };
}
const ucapan = (t: string): PeristiwaMentah => ({ tipe: "UCAPAN_PASIEN", transkrip: t });
const suratKontrol = (k = KARTU_SITI) => ({ ...rujukanUntuk(k), jenis: "surat_kontrol" as const });

// ---------------------------------------------------------------- skenario
test("skenario 1: alur bahagia lansia kontrol rutin → antrean dicetak", async () => {
  const { s, efek, jalur } = await jalankan([
    ucapan("iya boleh"),
    { tipe: "KARTU_TERBACA", identitas: KARTU_SITI },
    { tipe: "FRISTA", hasil: { hasil: "cocok" } },
    ucapan("kontrol rutin, Nak"),
    { tipe: "DOKUMEN_TERBACA", dokumen: suratKontrol() },
    ucapan("betul"),
    { tipe: "PETUGAS_SETUJU" },
  ]);
  assert.deepEqual(jalur, ["SAPA_IZIN", "MINTA_KARTU", "VERIFIKASI_WAJAH", "TANYA_KUNJUNGAN", "SCAN_DOKUMEN", "KONFIRMASI_DATA", "MENUNGGU_PETUGAS_CEK", "SELESAI"]);
  assert.equal(s.tag === "SELESAI" && s.hasil, "antrean_dicetak");
  assert.equal(s.k.sapaan, "Ibu");
  assert.ok(efek.some((e) => e.efek === "cetak_antrean"));
  assert.ok(!efek.some((e) => e.efek === "audit" && e.catatan.jenis === "bendera"), "tidak ada bendera");
});

test("skenario 2: wajah gelap lalu terlalu jauh → kios memandu, lalu cocok", async () => {
  const { s, efek } = await jalankan([
    ucapan("iya boleh"),
    { tipe: "KARTU_TERBACA", identitas: KARTU_AHMAD },
    { tipe: "FRISTA", hasil: { hasil: "wajah_tidak_terdeteksi", sebab: "gelap" } },
    { tipe: "FRISTA", hasil: { hasil: "wajah_tidak_terdeteksi", sebab: "terlalu_jauh" } },
    { tipe: "FRISTA", hasil: { hasil: "cocok" } },
  ]);
  assert.equal(s.tag, "TANYA_KUNJUNGAN");
  assert.ok(efek.some((e) => e.efek === "kamera" && e.aksi === "naikkan_eksposur"));
  const sub = efek.flatMap((e) => (e.efek === "bicara" ? [e.giliran.subtitle] : []));
  assert.ok(sub.includes("Lampu diterangkan. Lihat ke kamera lagi"));
  assert.ok(sub.includes("Sedikit maju… tahan sebentar"));
});

test("skenario 3: FRISTA tidak cocok dua kali → petugas, BUKAN ditolak", async () => {
  const { s, efek } = await jalankan([
    ucapan("iya boleh"),
    { tipe: "KARTU_TERBACA", identitas: KARTU_SITI },
    { tipe: "FRISTA", hasil: { hasil: "tidak_cocok" } },
    { tipe: "FRISTA", hasil: { hasil: "tidak_cocok" } },
    { tipe: "PETUGAS_TIBA" },
  ]);
  assert.equal(s.tag === "SELESAI" && s.hasil, "dilayani_petugas");
  assert.ok(efek.some((e) => e.efek === "panggil_petugas" && e.alasan === "frista_tidak_cocok"));
  assert.equal(efek.filter((e) => e.efek === "audit" && e.catatan.jenis === "frista").length, 2);
});

test("skenario 4: izin ditolak → petugas melayani; kios tidak menyentuh kartu", async () => {
  const { s, efek } = await jalankan([ucapan("nggak")]);
  assert.equal(s.tag === "MEMANGGIL_PETUGAS" && s.alasan, "izin_ditolak");
  assert.ok(!efek.some((e) => e.efek === "lampu" && e.target === "pemindai" && e.nyala));
  assert.ok(efek.some((e) => e.efek === "audit" && e.catatan.jenis === "izin" && !e.catatan.diberikan));
});

test("skenario 5: dua kali tidak jelas → petugas (tidak ada loop tanpa akhir)", async () => {
  const { s, efek } = await jalankan([ucapan("ehm gimana ya"), ucapan("ehm gimana ya")]);
  assert.equal(s.tag === "MEMANGGIL_PETUGAS" && s.alasan, "jawaban_tidak_jelas");
  const sub = efek.flatMap((e) => (e.efek === "bicara" ? [e.giliran.subtitle] : []));
  assert.deepEqual(sub, ["Boleh saya bantu daftar? Jawab: ya / tidak", "Cukup jawab: ya / tidak", "Petugas segera datang membantu"]);
});

test("skenario 6: pasien minta petugas di tengah alur", async () => {
  const { s } = await jalankan([
    ucapan("iya boleh"),
    { tipe: "KARTU_TERBACA", identitas: KARTU_SITI },
    { tipe: "FRISTA", hasil: { hasil: "cocok" } },
    ucapan("panggilkan suster saja"),
  ]);
  assert.equal(s.tag === "MEMANGGIL_PETUGAS" && s.alasan, "diminta_pasien");
});

test("skenario 7: nama di rujukan beda & kedaluwarsa → bendera, layar menandai ragu", async () => {
  const { s, efek } = await jalankan([
    ucapan("iya boleh"),
    { tipe: "KARTU_TERBACA", identitas: KARTU_SITI },
    { tipe: "FRISTA", hasil: { hasil: "cocok" } },
    ucapan("bawa surat dari puskesmas"),
    { tipe: "DOKUMEN_TERBACA", dokumen: rujukanUntuk(KARTU_SITI, { nama: "Sri Wahyuni", berlakuSampai: "2026-09-01" }) },
  ]);
  assert.equal(s.tag, "KONFIRMASI_DATA");
  const kolom = s.k.bendera.map((b) => b.kolom).sort();
  assert.deepEqual(kolom, ["nama", "rujukan_kedaluwarsa"]);
  const kartu = efek.find((e) => e.efek === "tampilkan_kartu");
  assert.ok(kartu && kartu.efek === "tampilkan_kartu" && kartu.isi.baris.find((b) => b.label === "Nama")?.ragu);
});

test("skenario 8: Jev nanggung + Claude setuju (bahasa Jawa) → diterima", async () => {
  const p = penilaiStandar();
  const { s } = await jalankan(
    [ucapan("iya boleh"), { tipe: "KARTU_TERBACA", identitas: KARTU_AHMAD }, { tipe: "FRISTA", hasil: { hasil: "cocok" } }, ucapan("kulo ajeng kontrol")],
    p,
  );
  assert.equal(s.tag, "SCAN_DOKUMEN");
  assert.equal(s.k.kunjungan, "kontrol");
  assert.equal(p.reqClaude.length, 1, "Claude hanya dipanggil sekali, saat nanggung");
});

test("skenario 9: Jev & Claude terputus → mode kata kunci, lalu petugas bila tetap tak jelas", async () => {
  const p = penilaiPalsu(() => "galat", () => "galat");
  const { s, jalur } = await jalankan([ucapan("iya, monggo"), { tipe: "KARTU_TERBACA", identitas: KARTU_AHMAD }, { tipe: "FRISTA", hasil: { hasil: "cocok" } }, ucapan("hmm"), ucapan("hmm")], p);
  assert.equal(jalur[1], "MINTA_KARTU", "‘iya, monggo’ dipahami kata kunci");
  assert.equal(s.tag === "MEMANGGIL_PETUGAS" && s.alasan, "layanan_ai_terputus");
});

test("skenario 10: angka dalam ucapan disamarkan sebelum dikirim ke Jev & Claude", async () => {
  const p = penilaiPalsu(() => ({ choice: "kontrol", confidence: 0.5 }), () => ({ opsi: "kontrol", minta_petugas: false }));
  await jalankan(
    [ucapan("iya boleh"), { tipe: "KARTU_TERBACA", identitas: KARTU_SITI }, { tipe: "FRISTA", hasil: { hasil: "cocok" } }, ucapan("kontrol, nomor saya 0001234567890")],
    p,
  );
  const terkirim = JSON.stringify([...p.reqJev, ...p.reqClaude]);
  assert.ok(!/\d{4,}/.test(terkirim.replace(/"(input|output)_tokens":\d+/g, "")), "tidak ada deret angka keluar dari kios");
  assert.ok(terkirim.includes("[angka]"));
});

// ---------------------------------------------------------------- properti (acak, ribuan alur)
const arbHasil = fc.oneof(
  fc.record({ jenis: fc.constant("pasti" as const), opsi: fc.constantFrom("ya", "tidak", "kontrol", "rujukan_baru", "lainnya"), sumber: fc.constantFrom("jev" as const, "jev+claude" as const, "claude" as const, "kata_kunci" as const) }),
  fc.record({ jenis: fc.constant("tanya_ulang" as const), sebab: fc.constantFrom("tidak_jelas" as const, "ragu" as const, "beda_pendapat" as const, "layanan_terputus" as const) }),
  fc.constant({ jenis: "minta_petugas" as const }),
  fc.constant({ jenis: "darurat" as const }),
);
const arbPeristiwa: fc.Arbitrary<Peristiwa> = fc.oneof(
  fc.tuple(fc.constantFrom("izin" as const, "kunjungan" as const, "konfirmasi" as const), arbHasil).map(([topik, hasil]) => ({ tipe: "JAWABAN", topik, hasil }) as Peristiwa),
  fc.constantFrom(KARTU_SITI, KARTU_AHMAD, { ...KARTU_AHMAD, statusPeserta: "tidak_aktif" as const }).map((identitas) => ({ tipe: "KARTU_TERBACA" as const, identitas })),
  fc.constantFrom<Peristiwa>(
    { tipe: "KARTU_GAGAL" }, { tipe: "DOKUMEN_GAGAL" }, { tipe: "TOMBOL_ULANGI" }, { tipe: "TOMBOL_PETUGAS" }, { tipe: "DIAM" },
    { tipe: "PETUGAS_TIBA" }, { tipe: "PETUGAS_SETUJU" }, { tipe: "PETUGAS_AMBIL_ALIH" },
    { tipe: "FRISTA", hasil: { hasil: "cocok" } }, { tipe: "FRISTA", hasil: { hasil: "tidak_cocok" } },
    { tipe: "FRISTA", hasil: { hasil: "wajah_tidak_terdeteksi", sebab: "gelap" } }, { tipe: "FRISTA", hasil: { hasil: "wajah_tidak_terdeteksi", sebab: "tertutup" } },
  ),
  fc.record({ nama: fc.constantFrom("Siti Aminah", "Sitti Aminah", "Budi"), exp: fc.constantFrom("2026-12-31", "2026-01-01"), yakin: fc.double({ min: 0.5, max: 1, noNaN: true }) })
    .map(({ nama, exp, yakin }) => ({ tipe: "DOKUMEN_TERBACA" as const, dokumen: rujukanUntuk(KARTU_SITI, { nama, berlakuSampai: exp }, yakin) })),
);

function cekGiliran(s: Keadaan, efek: readonly Efek[]) {
  for (const e of efek) {
    if (e.efek !== "bicara") continue;
    const { ucapan, subtitle } = e.giliran;
    assert.ok(subtitle.length <= 64, `subtitle terlalu panjang: ${subtitle}`);
    assert.ok(!/\d{4,}/.test(ucapan), "ucapan berisi deret angka");
    for (const k of [KARTU_SITI, KARTU_AHMAD]) {
      assert.ok(!ucapan.includes(k.nama) && !ucapan.includes(k.nik), "ucapan menyebut data pribadi");
    }
  }
  if (s.k.identitas) assert.ok(s.k.izin, "kartu diproses sebelum izin");
}

/** Peristiwa yang "diharapkan" keadaan saat ini → alur acak sering sampai akhir, bukan macet di awal. */
function harapan(s: Keadaan, pilih: number): Peristiwa {
  const ya = { jenis: "pasti", opsi: "ya", sumber: "jev" } as const;
  const daftar: Peristiwa[] = (() => {
    switch (s.tag) {
      case "SAPA_IZIN": return [{ tipe: "JAWABAN", topik: "izin", hasil: ya }];
      case "MINTA_KARTU": return [{ tipe: "KARTU_TERBACA", identitas: KARTU_SITI }, { tipe: "KARTU_TERBACA", identitas: KARTU_AHMAD }];
      case "VERIFIKASI_WAJAH": return [{ tipe: "FRISTA", hasil: { hasil: "cocok" } }];
      case "TANYA_KUNJUNGAN": return [
        { tipe: "JAWABAN", topik: "kunjungan", hasil: { jenis: "pasti", opsi: "kontrol", sumber: "jev" } },
        { tipe: "JAWABAN", topik: "kunjungan", hasil: { jenis: "pasti", opsi: "rujukan_baru", sumber: "jev+claude" } },
      ];
      case "SCAN_DOKUMEN": return [{ tipe: "DOKUMEN_TERBACA", dokumen: rujukanUntuk(s.k.identitas ?? KARTU_SITI) }];
      case "KONFIRMASI_DATA": return [{ tipe: "JAWABAN", topik: "konfirmasi", hasil: ya }];
      case "MENUNGGU_PETUGAS_CEK": return [{ tipe: "PETUGAS_SETUJU" }, { tipe: "PETUGAS_AMBIL_ALIH" }];
      case "MEMANGGIL_PETUGAS": return [{ tipe: "PETUGAS_TIBA" }];
      case "SELESAI": return [{ tipe: "TOMBOL_ULANGI" }];
    }
  })();
  return daftar[pilih % daftar.length]!;
}
const arbLangkah = fc.tuple(fc.integer({ min: 0, max: 9 }), arbPeristiwa, fc.nat());

test("properti: 3.000 alur acak tidak pernah crash, tidak mengucapkan data pribadi, dan izin selalu lebih dulu", () => {
  const akhir = { antrean_dicetak: 0, dilayani_petugas: 0 };
  fc.assert(
    fc.property(fc.array(arbLangkah, { maxLength: 40 }), (urutan) => {
      let r = mulai(HARI_INI);
      cekGiliran(r.berikut, r.efek);
      for (const [dadu, acak, pilih] of urutan) {
        const p = dadu < 7 ? harapan(r.berikut, pilih) : acak; // 70% kooperatif, 30% kacau
        r = langkah(r.berikut, p);
        cekGiliran(r.berikut, r.efek);
        for (const e of r.efek) {
          if (e.efek === "kirim_draf_ke_petugas" && e.draf.identitas) assert.ok(r.berikut.k.izin);
          if (e.efek === "panggil_petugas") assert.ok(r.efek.some((x) => x.efek === "audit" && x.catatan.jenis === "eskalasi"), "eskalasi tanpa audit");
        }
      }
      if (r.berikut.tag === "SELESAI") akhir[r.berikut.hasil]++;
    }),
    { numRuns: 3000 },
  );
  // Generator harus benar-benar menjelajah kedua akhir; kalau tidak, properti di atas tidak berarti.
  assert.ok(akhir.antrean_dicetak > 100 && akhir.dilayani_petugas > 100, JSON.stringify(akhir));
});

test("properti: dari keadaan mana pun, pasien yang diam selalu sampai ke petugas, lalu selesai dilayani", () => {
  fc.assert(
    fc.property(fc.array(arbPeristiwa, { maxLength: 40 }), (awalan) => {
      let s = mulai(HARI_INI).berikut;
      for (const p of awalan) s = langkah(s, p).berikut;
      for (let i = 0; i < BATAS.tanyaUlang; i++) s = langkah(s, { tipe: "DIAM" }).berikut;
      assert.ok(["MEMANGGIL_PETUGAS", "MENUNGGU_PETUGAS_CEK", "SELESAI"].includes(s.tag), `macet di ${s.tag}`);
      s = langkah(s, { tipe: "PETUGAS_TIBA" }).berikut;
      s = langkah(s, { tipe: "PETUGAS_AMBIL_ALIH" }).berikut;
      assert.equal(s.tag, "SELESAI");
      assert.ok(s.tag === "SELESAI" && (s.hasil === "antrean_dicetak" || s.hasil === "dilayani_petugas"));
    }),
    { numRuns: 3000 },
  );
});

test("skenario 11: keluhan darurat di tengah pertanyaan → petugas SEGERA, menang atas jawaban", async () => {
  const p = penilaiPalsu(
    (u) => (u.includes("sesak") ? { choice: "ya", confidence: 0.9, darurat: 0.85 } : { choice: "ya", confidence: 0.9 }),
    () => ({ opsi: "ya", minta_petugas: false }),
  );
  const { s, efek } = await jalankan([ucapan("iya boleh, tapi saya sesak dari tadi")], p);
  assert.equal(s.tag === "MEMANGGIL_PETUGAS" && s.alasan, "kemungkinan_darurat");
  assert.ok(efek.some((e) => e.efek === "panggil_petugas" && e.prioritas === "segera"));
  assert.ok(!efek.some((e) => e.efek === "lampu" && e.target === "pemindai" && e.nyala), "tidak lanjut minta kartu");
});

test("skenario 12: darurat saat sudah menunggu petugas biasa → prioritas dinaikkan", () => {
  let s = mulai(HARI_INI).berikut;
  s = langkah(s, { tipe: "TOMBOL_PETUGAS" }).berikut;
  const r = langkah(s, { tipe: "JAWABAN", topik: "izin", hasil: { jenis: "darurat" } });
  assert.ok(r.efek.some((e) => e.efek === "panggil_petugas" && e.prioritas === "segera"));
});
