import { writeFileSync } from "node:fs";
import { mulai, type Keadaan, type Pandu } from "../src/mesin.js";
import { giliranUntuk } from "../src/naskah.js";
import { ALASAN_PETUGAS } from "../src/domain.js";
import { KARTU_SITI } from "../test/palsu.js";
const k0 = mulai("2026-10-12").berikut.k;
const k = { ...k0, izin: true, identitas: KARTU_SITI, sapaan: "Ibu" as const };
const v: [string, Keadaan][] = [
  ["pertama", { tag: "SAPA_IZIN", k: k0 }],
  ["diulang", { tag: "SAPA_IZIN", k: { ...k0, ulang: 1 } }],
  ["pertama", { tag: "MINTA_KARTU", k: { ...k0, izin: true }, percobaan: 1 }],
  ["gagal baca", { tag: "MINTA_KARTU", k: { ...k0, izin: true }, percobaan: 2 }],
  ...(["awal", "terang", "maju", "lepas_penutup", "ulang"] as Pandu[]).map((p): [string, Keadaan] => [p.replace("_", " "), { tag: "VERIFIKASI_WAJAH", k, percobaan: 1, tidakCocok: 0, pandu: p }]),
  ["pertama", { tag: "TANYA_KUNJUNGAN", k }],
  ["diulang", { tag: "TANYA_KUNJUNGAN", k: { ...k, ulang: 1 } }],
  ["kontrol", { tag: "SCAN_DOKUMEN", k: { ...k, kunjungan: "kontrol" }, percobaan: 1 }],
  ["rujukan baru", { tag: "SCAN_DOKUMEN", k: { ...k, kunjungan: "rujukan_baru" }, percobaan: 1 }],
  ["gagal baca", { tag: "SCAN_DOKUMEN", k: { ...k, kunjungan: "kontrol" }, percobaan: 2 }],
  ["pertama", { tag: "KONFIRMASI_DATA", k }],
  ["diulang", { tag: "KONFIRMASI_DATA", k: { ...k, ulang: 1 } }],
  ["", { tag: "MENUNGGU_PETUGAS_CEK", k }],
  ...ALASAN_PETUGAS.map((a): [string, Keadaan] => [a.replace(/_/g, " "), { tag: "MEMANGGIL_PETUGAS", k, alasan: a }]),
  ["antrean dicetak", { tag: "SELESAI", k, hasil: "antrean_dicetak" }],
  ["dilayani petugas", { tag: "SELESAI", k, hasil: "dilayani_petugas" }],
];
writeFileSync("naskah.json", JSON.stringify(v.map(([varian, s]) => ({ keadaan: s.tag, varian, ...giliranUntuk(s) }))));
console.log(v.length);
