/**
 * Evaluasi pemahaman pada set ujaran berlabel.
 *  - Selalu: baseline kata kunci (tanpa AI, offline).
 *  - Bila TYPESAFE_API_KEY ada: Jev saja.
 *  - Bila keduanya ada: kebijakan lengkap Jev + Claude.
 * Keluaran: akurasi, laju "aman" (salah tapi bertanya ulang/memanggil petugas), dan
 * SALAH-YAKIN (salah sekaligus diterima) — metrik yang paling penting untuk kios.
 */
import { readFileSync } from "node:fs";
import Anthropic from "@anthropic-ai/sdk";
import { TypeSafeClient } from "@typesafe-ai/sdk";
import { buatPenilaiClaude, buatPenilaiJev, nilaiKataKunci, pahami, type Penilai } from "../src/pemahaman.js";
import type { Topik } from "../src/pertanyaan.js";
import { samarkan } from "../src/samarkan.js";
import { PERTANYAAN } from "../src/pertanyaan.js";

interface Kasus { topik: Topik; ujaran: string; label: string }
const { kasus } = JSON.parse(readFileSync(new URL("./ujaran-lansia.json", import.meta.url), "utf8")) as { kasus: Kasus[] };
const PERTANYAAN_KIOS: Record<Topik, string> = {
  izin: "Boleh saya bantu daftar? Jawab: ya / tidak",
  kunjungan: "Kontrol, atau bawa rujukan baru?",
  konfirmasi: "Data di layar sudah betul? Jawab: ya / tidak",
};

type Keluaran = string; // opsi | tidak_jelas | minta_petugas
interface Ringkas { benar: number; salahAman: number; salahYakin: number; daruratTerlewat: number; ms: number[] }

function catat(r: Ringkas, label: string, keluar: Keluaran, ms: number) {
  r.ms.push(ms);
  if (keluar === label) r.benar++;
  else if (label === "darurat") { r.salahYakin++; r.daruratTerlewat++; } // darurat yang terlewat selalu dihitung berbahaya
  else if (keluar === "tidak_jelas" || keluar === "minta_petugas" || keluar === "darurat") r.salahAman++;
  else r.salahYakin++;
}
const baru = (): Ringkas => ({ benar: 0, salahAman: 0, salahYakin: 0, daruratTerlewat: 0, ms: [] });

function cetak(nama: string, r: Ringkas) {
  const n = kasus.length;
  const ms = [...r.ms].sort((a, b) => a - b);
  const p = (q: number) => ms[Math.min(ms.length - 1, Math.floor(q * ms.length))]?.toFixed(0) ?? "-";
  console.log(
    `${nama.padEnd(22)} benar ${((100 * r.benar) / n).toFixed(1).padStart(5)}%  | salah-aman ${String(r.salahAman).padStart(2)} | SALAH-YAKIN ${String(r.salahYakin).padStart(2)} | darurat terlewat ${r.daruratTerlewat} | p50 ${p(0.5)} ms, p95 ${p(0.95)} ms`,
  );
}

async function main() {
  const kk = baru();
  for (const c of kasus) {
    const t0 = performance.now();
    const k = nilaiKataKunci(c.topik, samarkan(c.ujaran));
    catat(kk, c.label, k.darurat ? "darurat" : k.mintaPetugas ? "minta_petugas" : k.opsi, performance.now() - t0);
  }
  console.log(`Set: ${kasus.length} ujaran, ${Object.keys(PERTANYAAN).length} pertanyaan\n`);
  cetak("Kata kunci (tanpa AI)", kk);

  const punyaJev = !!process.env.TYPESAFE_API_KEY;
  const punyaClaude = !!process.env.ANTHROPIC_API_KEY;
  if (!punyaJev) {
    console.log("\n(TYPESAFE_API_KEY tidak ada: Jev dilewati. Isi kunci lalu jalankan `npm run eval` lagi.)");
    return;
  }
  const jev = buatPenilaiJev(new TypeSafeClient());
  const claude = punyaClaude ? buatPenilaiClaude(new Anthropic()) : null;

  for (const [nama, penilai] of [["Jev saja", { jev, claude: null }], ...(claude ? [["Jev + Claude", { jev, claude }]] : [])] as [string, Penilai][]) {
    const r = baru();
    for (const c of kasus) {
      const t0 = performance.now();
      const { hasil } = await pahami(c.topik, { pertanyaanKios: PERTANYAAN_KIOS[c.topik], ujaran: samarkan(c.ujaran) }, penilai);
      const keluar = hasil.jenis === "pasti" ? hasil.opsi : hasil.jenis === "tanya_ulang" ? "tidak_jelas" : hasil.jenis;
      catat(r, c.label, keluar, performance.now() - t0);
    }
    cetak(nama, r);
  }
}
main().catch((e) => { console.error(e); process.exit(1); });
